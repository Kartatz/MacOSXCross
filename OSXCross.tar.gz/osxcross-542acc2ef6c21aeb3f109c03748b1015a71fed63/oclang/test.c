#include <stdio.h>

int main()
{
    printf("works");
    return 0;
}
